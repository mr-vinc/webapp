<!DOCTYPE html>
<html>

<head>
	<title>jQuery Mobile page</title>
	<meta charset="utf-8" />
	<!-- Hier staan alle css en style achtige js bestanden-->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="themes/test.css" />
	<link rel="stylesheet" href="themes/test.min.css" />
	<link rel="stylesheet" href="themes/jquery.mobile.icons.min.css" />
	<link rel="stylesheet" href="themes/jquery.mobile.structure-1.4.5.min.css" />
	<script src="themes/jquery-1.11.1.min.js"></script>
	<script src="themes/jquery.mobile-1.4.5.min.js">
	</script>
	<style>
		img {
			margin-left: 10px;
			margin-right: 10px;
			width: 150px;
			height: 150px;
		}
	</style>
</head>
<!-- Hieronder maken we een form aan waarin we de gebruiker vragen naar zijn geiwcht en lengte als op de submit knop wordt geklikt dan worden de waardes ddorgegeven naar PHP-->

<body>
	<div data-role="page">
		<div data-role="header">
			<h1>BMI</h1>
		</div>
		<div role="main" class="ui-content">
			<p>Gebruik de BMI-calculator om uw ideale gewicht te bepalen</p>
			<form action="BMI.php" method="post">
				<label for="gewicht">Gewicht (kg):</label>
				<input name="gewicht" id="gewicht" type="range" min="30" max="200" step="1" value="60" data-highlight="true">
				<label for="lengte">Lengte (cm):</label>
				<input name="lengte" id="lengte" type="range" min="130" max="230" step="1" value="160" data-highlight="true">
				<label class="ui-hidden-accessible" for="bereken">Bereken:</label>
				<button class="ui-shadow ui-btn ui-corner-all ui-mini" id="bereken" type="submit" name="bereken">Bereken BMI</button>
			</form>

			<?php 
//Hier worden de waardes opgehaald en pas gebruikt als er op de submit knop is gedrukt.
if (isset($_POST["bereken"])) {
	
$gewicht = $_POST["gewicht"];
$lengte = $_POST["lengte"];
//hier wordt het bmi berekent.
$lengteinmeters = $lengte / 100;
$bmi = $gewicht / ($lengteinmeters * $lengteinmeters);
$bmiafgerond = round($bmi, 1);
echo "Uw BMI is " . $bmiafgerond;
//hier wordt op basis van het berekende bmi een plaatje en een tekst weergegeven
if($bmiafgerond >= 0 && $bmiafgerond <= 15) {
	echo "U heeft ondergewicht";
	echo "<img src='https://gezondetips.nl/wp-content/uploads/2014/05/ondergewicht.jpg'>";
}
else if ($bmiafgerond > 15 && $bmiafgerond <= 25) {
	echo "U heeft een normaal gewicht";
	echo "<img src='https://echtgezondafvallen.nl/wp-content/uploads/2014/05/gezond-gewicht.jpg'>";
}
else if ($bmiafgerond > 25) {
	echo "U heeft overgewicht";
	echo "<img src='https://www.nlbewustgezond.nl/app/uploads/2017/01/Overgewicht-1090x727.jpg'>";
};
};
?>

		</div>
	</div>
</body>

</html>