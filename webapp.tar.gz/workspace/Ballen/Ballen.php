<!DOCTYPE html>
<html>
<head>
	<!-- Alle scripts enz ophalen zodat de pagina een mooie schalende lay out heeft -->
  <title>Ballen trekken ;] </title>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="themes/test.css" />
  <link rel="stylesheet" href="themes/test.min.css" />
  <link rel="stylesheet" href="themes/jquery.mobile.icons.min.css" />
  <link rel="stylesheet" href="themes/jquery.mobile.structure-1.4.5.min.css" />
  <script src="themes/jquery-1.11.1.min.js"></script>
  <script src="themes/jquery.mobile-1.4.5.min.js"></script>
</head>
  <body>
		<div data-role="page">
			<div data-role="header">
				<h1>RANDOM numbers</h1>
			</div>
			<!-- Hier wordt een form aangemaakt met daarin drie sliders en een submit button -->
			<div role="main" class="ui-content">
				Deze WebApp simuleert het trekken van gekleurde ballen MET teruglegging.
				<form action="Ballen.php" method="post">
					<label for="getal1">Aantal RODE ballen:</label>
					<input name="getal1" id="getal1" type="range" min="1" max="9" step="1" value="5" data-highlight="true">
					<label for="getal2">Aantal BLAUWE ballen:</label>
					<input name="getal2" id="getal2" type="range" min="1" max="9" step="1" value="5" data-highlight="true">
					<label for="aantal">Kies een aantal:</label>
					<input name="aantal" id="aantal" type="range" min="1" max="100" step="1" value="50" data-highlight="true">					
					<label class="ui-hidden-accessible" for="simuleer">Simuleer:</label>
					<button class="ui-shadow ui-btn ui-corner-all ui-mini" id="simuleer" type="submit" name="simuleer">SIMULEER</button>
				</form>
				
				<?php 
				//Checken of er op submit geklikt is:
				if(isset($_POST["simuleer"])){
				//Waardes ophalen:
					$rood = $_POST["getal1"];
					$blauw = $_POST["getal2"];
					$totaal = $rood + $blauw;
					$aantal = $_POST["aantal"];
				//Een waarde aanmaken die bijhoudt hoeveel rode en blauwe ballen er zijn:
				$roodaantal = 0;
			  $blauwaantal = 0;
			  //bijhouden hoeveel ballen er al zijn getrokken:
			  $aantalgetrokkenballen = 0;
			  //While loop maken. Zolang $aantalgetrokkenballen kleiner is dan $aantal door blijven gaan met trekken;
			  while($aantalgetrokkenballen < $aantal){
			  	$aantalgetrokkenballen = $aantalgetrokkenballen + 1;
			  	//Hier wordt een random waarde gegenereerd tussen de 1 en de waarde van $totaal
			  	$trektbal = rand(1, $totaal);
			  
			  //Als trekt kliner of gelijk is dan/aan $rood dan wordt er een R geprint en dan wordt het totaal aantal rode ballen met 1 verhoogd.
			  //Als dat niet zo is wordt er een B geprint en wordt het totaal aantal blauwe ballen verhoogd.
					if($trektbal <= $rood){
						print "R ";
						$roodaantal = $roodaantal + 1;
					}
					else {
						print "B ";
						$blauwaantal = $blauwaantal + 1;
					}
			  }
			  //Hier printen we even de totale uitkomst:
			  print "Totaal aantal rode ballen is: " . $roodaantal . " Het totaal aantal blauwe ballen is: " . $blauwaantal . " gefeliciteerd ga nu alsjeblieft iets nuttigs doen!";
				};
			
				?>
								
			</div>
			<div data-role="footer" data-position="fixed">
				<h3>&copy; Vincent & CO</h3>
			</div>
		</div>
  </body>
</html>