<?php 
//Session wordt gestart:
session_start();
//Als er op opnieuw wordt geklikt wordt de session opnieuw begonnen:
if(isset($_POST["opnieuw"])){
	session_destroy();
	session_start();
};
//Hier krijgen de sessions een waarde en de totale waarden de startwaarde:
if(!isset($_SESSION["dobbel1"])){
$_SESSION["dobbel1"] = 3;
$_SESSION["dobbel2"] = 1;
$_SESSION["dobbel3"] = 6;
$_SESSION["dobbel1tot"] = 3;
$_SESSION["dobbel2tot"] = 1;
$_SESSION["dobbel3tot"] = 6;
};
//hier wordt een variabele aantal aangemaakt en ingesteld op 0:
if(!isset($_SESSION["aantal"])){
	$_SESSION["aantal"] = 0;
};

//Deze functie wordt uitgevoerd als er op verzend is geklikt:
if(isset($_POST["verzend"])){
	//waarde van aantal met 1 verhogen:
	$_SESSION["aantal"] = $_SESSION["aantal"] + 1;
	//Hier wordt een random waarde van 1 tot 6 gegenereerd:
	$dobbel = rand(1,6);
	//Waarde van verzend ophalen die is 1, 2 of 3 afhankelijk van de dobbelsteen watop is geklikt:
	$verzend = $_POST["verzend"];
	//Hier wordt op basis van welke dobbelsteen is aangeklikt de juiste session aangepast:
	if($verzend == 1){
		//de dobbelsteen krijgt de waarde van het random gekozen getal:
		$_SESSION["dobbel1"] = $dobbel;
		//De totaal waarde van het aantal ogen wordt verhoogd met de random gekozen waarde:
		$_SESSION["dobbel1tot"] = $_SESSION["dobbel1tot"] + $dobbel;
	}
	elseif($verzend == 2){
		//de dobbelsteen krijgt de waarde van het random gekozen getal:
		$_SESSION["dobbel2"] = $dobbel;
		//De totaal waarde van het aantal ogen wordt verhoogd met de random gekozen waarde:
		$_SESSION["dobbel2tot"] = $_SESSION["dobbel2tot"] + $dobbel;
	}
	elseif($verzend == 3){
		//de dobbelsteen krijgt de waarde van het random gekozen getal:
		$_SESSION["dobbel3"] = $dobbel;
		//De totaal waarde van het aantal ogen wordt verhoogd met de random gekozen waarde:
		$_SESSION["dobbel3tot"] = $_SESSION["dobbel3tot"] + $dobbel;
	};
};

//Hier worden alle waarden opgeslagen in niet session waardes:
$dobbel1 = $_SESSION["dobbel1"];
$dobbel2 = $_SESSION["dobbel2"];
$dobbel3 = $_SESSION["dobbel3"];
$dobbel1tot = $_SESSION["dobbel1tot"];
$dobbel2tot = $_SESSION["dobbel2tot"];
$dobbel3tot = $_SESSION["dobbel3tot"];

?>

<!DOCTYPE html>
<html>
 <head>
	<!-- Alle scripts enz ophalen zodat de pagina een mooie schalende lay out heeft -->
  <title>Dobbelen ;) </title>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="themes/test.css" />
  <link rel="stylesheet" href="themes/test.min.css" />
  <link rel="stylesheet" href="themes/jquery.mobile.icons.min.css" />
  <link rel="stylesheet" href="themes/jquery.mobile.structure-1.4.5.min.css" />
  <script src="themes/jquery-1.11.1.min.js"></script>
  <script src="themes/jquery.mobile-1.4.5.min.js"></script>
</head>
  <body>
		<div data-role="page">
			<div data-role="header">
				<h1>3_DOB</h1>
			</div>
			<div role="main" class="ui-content" style="padding:0px;">
				<fieldset class="ui-grid-b">
					<div class="ui-block-a">
					<form action="dobbelstenen.php" method="post">
						<input type="hidden" name="verzend" value="1" />
						<input type="image" src="dobbel<?php print "$dobbel1" ?>.gif" style="max-width:100%" />
					</form>
					</div>
					<div class="ui-block-b">
					<form action="dobbelstenen.php" method="post">
						<input type="hidden" name="verzend" value="2" />
						<input type="image" src="dobbel<?php print "$dobbel2" ?>.gif" style="max-width:100%" />
					</form>
					</div>
					<div class="ui-block-c">
					<form action="dobbelstenen.php" method="post">
						<input type="hidden" name="verzend" value="3" />
						<input type="image" src="dobbel<?php print "$dobbel3" ?>.gif" style="max-width:100%" />
					</form>					
					</div>
					<div class="ui-block-a">
					Totaal: <?php print $dobbel1tot ?>					</div>
					<div class="ui-block-b">
					Totaal: <?php print $dobbel2tot ?>					</div>
					<div class="ui-block-c">
					Totaal: <?php print $dobbel3tot ?>					</div>
				</fieldset>
				
				<form action="dobbelstenen.php" method="post">
					<button class="ui-shadow ui-btn ui-corner-all ui-mini" id="opnieuw" type="submit" name="opnieuw">Begin opnieuw</button>
				</form>		
			</div>
			<div data-role="footer" data-position="fixed">
				<h3>&copy; Vincent & CO </h3>
			</div>
		</div>
  </body>
</html>