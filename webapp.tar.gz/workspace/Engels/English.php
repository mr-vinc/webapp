<?php 
//Hier worden de sessie variabelen aangemaakt. En deze krijgen al een waarde als ze die nog niet hebben.
session_start();
if(!isset($_SESSION["aantalgoed"])){
	$_SESSION["aantalgoed"] = 0;
};
if(!isset($_SESSION["aantalfout"])){
	$_SESSION["aantalfout"] = 0;
};
?>

<!DOCTYPE html>
<html>
<head>
	<!-- Alle scripts enz ophalen zodat de pagina een mooie schalende lay out heeft -->
  <title> Engels leren ;] </title>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="themes/test.css" />
  <link rel="stylesheet" href="themes/test.min.css" />
  <link rel="stylesheet" href="themes/jquery.mobile.icons.min.css" />
  <link rel="stylesheet" href="themes/jquery.mobile.structure-1.4.5.min.css" />
  <script src="themes/jquery-1.11.1.min.js"></script>
  <script src="themes/jquery.mobile-1.4.5.min.js"></script>
</head>

  <body>
		<div data-role="page">
			<div data-role="header">
			<a class="ui-btn-right" href="English.php?id=opnieuw" data-icon="recycle" data-iconpos="notext">O</a>
				<h1>ENGELS leren</h1>
			</div>
			<div role="main" class="ui-content">
				<!-- Hier wordt een form aangemaakt dat de user de keuze geeft om een Nederlands of Engels woord te kiezen, zodat de user die kan vertalen en zo slimmer kan worden. -->
				<form action="English.php" method="post">
					<label class="ui-hidden-accessible" for="engels">Engels woord: </label>
					<button class="ui-shadow ui-btn ui-corner-all ui-mini" id="engels" type="submit" name="engels">KIES een ENGELS woord</button>
					<label class="ui-hidden-accessible" for="nederlands">Nederlands woord: </label>
					<button class="ui-shadow ui-btn ui-corner-all ui-mini" id="nederlands" type="submit" name="nederlands">KIES een NEDERLANDS woord</button>
				</form>	
				<?php 
				//Deze if functie wordt alleen in gang gezet als de user gekozen heeft voor de optie vertalen van EN naar Ne.
				if(isset($_POST["engels"])){
					$_SESSION["keuze1"] = 1;
					$_SESSION["keuze2"] = 0;
					//Hier staan de drie vertaalbare woorden in een array
					$engelswoorden = array("tree", "table", "head");
					//Hier worden de worden geshuffled zodat ze random in de array zitten
					shuffle($engelswoorden);
					//Hier wordt het eerste woord uit de array genomen en in een sessie variable opgeslagen. Aangezien de array steeds verandert blijft deze waarde random.
					$_SESSION["randomengels"] = $engelswoorden[0];
				};
				//Deze if functie wordt alleen in gang gezet als de user gekozen heeft voor de optie vertalen van Ne naar En.
				if(isset($_POST["nederlands"])){
					$_SESSION["keuze2"] = 1;
					$_SESSION["keuze1"] = 0;
					//Hier staan de drie vertaalbare woorden in een array
					$nederlandswoorden = array("boom", "tafel", "hoofd");
					//Hier worden de worden geshuffled zodat ze random in de array zitten
					shuffle($nederlandswoorden);
					//Hier wordt het eerste woord uit de array genomen en in een sessie variable opgeslagen. Aangezien de array steeds verandert blijft deze waarde random.
					$_SESSION["randomnederlands"] = $nederlandswoorden[0];
				};
				 //Hier wordt op basis van de aangeklikte button uit het form een random En of Ne woord geprint wat de user vervolgens moet vertalen (Naja je moet niets...).
				 if($_SESSION["keuze1"] == 1){echo "Translate " . $_SESSION["randomengels"];}; 
				 if($_SESSION["keuze2"] == 1){echo "Vertaal " . $_SESSION["randomnederlands"];}; 
				?> 
				
				<!-- Met behulp van dit form wordt het antwoord van de user op de vraag opgeslagen. -->
				<form action="English.php" method="post" id="form2">
					<label class="ui-hidden-accessible" for="vertaling">Vertaling:</label>
					<input name="vertaling" id="vertaling" type="text" placeholder="Geef de vertaling:" data-mini="true" required>
					<label class="ui-hidden-accessible" for="controleer">Controleer:</label>
					<button class="ui-shadow ui-btn ui-corner-all ui-mini" id="controleer" type="submit" name="controleer">CONTROLEER</button>
				</form>	
		
				<?php
				//Hier is een grote if functie die alleen wordt uitgevoerd, mits de user een antwoord heeft gegeven. Hier wordt gecheckt of het gegeven antwoord klopt en als dat zo is dan wordt aantal goed verhoogd, zo niet dan wordt aantal fout verhoogd.	
				if(isset($_POST["controleer"])){
					$_SESSION["antwoord"] = $_POST["vertaling"];
					if($_SESSION["keuze1"] == 1){
						if($_SESSION["randomengels"] == "tree" && $_SESSION["antwoord"] == "boom"){
							echo	"Deze vertaling is goed!";
							$_SESSION["aantalgoed"] ++;
						}
						elseif($_SESSION["randomengels"] == "table" && $_SESSION["antwoord"] == "tafel"){
							echo	"Deze vertaling is goed!";
							$_SESSION["aantalgoed"] ++;
						}	
						elseif($_SESSION["randomengels"] == "head" && $_SESSION["antwoord"] == "hoofd"){
							echo	"Deze vertaling is goed!";	
							$_SESSION["aantalgoed"] ++;
						}
						else{
							echo	"Deze vertaling is fout!";
							$_SESSION["aantalfout"] ++;
						};
					};
				
					if($_SESSION["keuze2"] == 1){
						if($_SESSION["randomnederlands"] == "boom" && $_SESSION["antwoord"] == "tree"){
							echo	"Deze vertaling is goed!";
							$_SESSION["aantalgoed"] ++;
						}
						elseif($_SESSION["randomnederlands"] == "tafel" && $_SESSION["antwoord"] == "table"){
							echo	"Deze vertaling is goed!";
							$_SESSION["aantalgoed"] ++;
						}	
						elseif($_SESSION["randomnederlands"] == "hoofd" && $_SESSION["antwoord"] == "head"){
							echo	"Deze vertaling is goed!";
							$_SESSION["aantalgoed"] ++;
						}
						else{
							echo	"Deze vertaling is fout!";
							$_SESSION["aantalfout"] ++;
						};
					};
				};
				//Hier wordt het aantal goed en fout geprint.
				echo " <br> Aantal goed: " . $_SESSION["aantalgoed"];
				echo " Aantal fout: " . $_SESSION["aantalfout"];
				?>
				
			<div data-role="footer" data-position="fixed">
				<h3>&copy; Vincent & CO </h3>
			</div>
		</div>
  </body>
</html>