<!DOCTYPE html>
<html>
<head>
	<!-- Alle scripts enz ophalen zodat de pagina een mooie schalende lay out heeft -->
  <title>Ballen trekken ;] </title>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="themes/test.css" />
  <link rel="stylesheet" href="themes/test.min.css" />
  <link rel="stylesheet" href="themes/jquery.mobile.icons.min.css" />
  <link rel="stylesheet" href="themes/jquery.mobile.structure-1.4.5.min.css" />
  <script src="themes/jquery-1.11.1.min.js"></script>
  <script src="themes/jquery.mobile-1.4.5.min.js"></script>
</head>
<!-- Helaas heb ik niet genoeg tijd gehad om deze opdracht af te kunnen maken. Wellicht kan ik nog een paar tienden scoren met hetgeen dat ik al wel heb... :( -->
  <body>
		<div data-role="page">
			<div data-role="header">
				<h1>RAAD<br />het<br />WOORD</h1>
			</div>
			<div role="main" class="ui-content">
				<form action="raadhetwoord.php" method="post" id="form1">
					<label class="ui-hidden-accessible" for="woord1">Vul nieuw woord in:</label>
					<input name="woord1" id="woord1" type="text" placeholder="Vul nieuw woord in:" data-mini="true" required>
					<label class="ui-hidden-accessible" for="nieuw">Zoek:</label>
					<button class="ui-shadow ui-btn ui-corner-all ui-mini" id="nieuw" type="submit" name="nieuw">NIEUW WOORD</button>
				</form>	
								<form action="raadhetwoord.php" method="post" id="form2">
					<label class="ui-hidden-accessible" for="woord2">Raad het woord:</label>
					<input name="woord2" id="woord2" type="text" placeholder="Raad het woord:" data-mini="true" required>
					<label class="ui-hidden-accessible" for="raad">Raad:</label>
					<button class="ui-shadow ui-btn ui-corner-all ui-mini" id="raad" type="submit" name="raad">RAAD het WOORD</button>
				</form>	
							</div>
					<?php 
					
					$woord1 = $_POST["woord1"];
					$deel = str_split($woord1, 1);
					print_r($deel);
					$gegevenwoord = array($woord1);
					
					?>
							
			<div data-role="footer" data-position="fixed">
				<h3>&copy; Vincent & CO </h3>
			</div>
		</div>
  </body>
</html>