<!DOCTYPE html>
<html>

<head>
 <title>jQuery Mobile page</title>
 <meta charset="utf-8" />
 <!-- Hier staan alle css en style achtige js bestanden-->
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="themes/test.css" />
 <link rel="stylesheet" href="themes/test.min.css" />
 <link rel="stylesheet" href="themes/jquery.mobile.icons.min.css" />
 <link rel="stylesheet" href="themes/jquery.mobile.structure-1.4.5.min.css" />
 <script src="themes/jquery-1.11.1.min.js"></script>
 <script src="themes/jquery.mobile-1.4.5.min.js">
 </script>
</head>

<body>
 <div data-role="page">
   <div data-role="header">
				<h1>DE TIJD BEREKEN!</h1>
			</div>
			<div role="main" class="ui-content">
				<p>Met deze WebApp is het mogelijk uren, minuten en seconden om te rekenen naar seconden.</p>
				<!-- hier wordt een form aangemaakt om de data uit de sliders door te kunnen geven aan php we halen het aantal uren minuten en seconden op en hebben als laatst een button waarmee alle waardes worden doorgegeven aan php en daar verder mee gerekend wordt-->
				<form action="Tijdv1.php" method="post">
					<label for="aantal_uren">Aantal uren:</label>
					<input name="aantal_uren" id="aantal_uren" type="range" min="0" max="23" step="1" value="12" data-highlight="true">	
					<label for="aantal_min">Aantal minuten:</label>
					<input name="aantal_min" id="aantal_min" type="range" min="0" max="59" step="1" value="30" data-highlight="true">
					<label for="aantal_sec">Aantal seconden:</label>
					<input name="aantal_sec" id="aantal_sec" type="range" min="0" max="59" step="1" value="30" data-highlight="true">				
					<label class="ui-hidden-accessible" for="bereken">Bereken:</label>
					<button class="ui-shadow ui-btn ui-corner-all ui-mini" id="bereken" type="submit" name="bereken">BEREKEN</button>
				</form>
<?php 
//Hier rekenen we de uren minuten en seconden om in het aantal seconden en vervolgens echooen we dat.
$totaal = ($_POST["aantal_uren"] * 3600) + ($_POST["aantal_min"] * 60) + $_POST["aantal_sec"];
echo "Het door u aangegeven aantal uren, minuten en seconden is omgerekend " . $totaal . " seconden"; 
?>
			</div>
			 
			</div>
</body>

</html>