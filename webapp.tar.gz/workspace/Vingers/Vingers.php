<?php 
//Session starten:
session_start();
//Als de pagina wordt geladen heeft session waarde van 1 en dus wordt afb 1 getoont want submit is nog niet ingedrukt:
if(!isset($_POST["volgende"])){
$_SESSION["afb"] = 1;
	};
?>

<!DOCTYPE html>
<html>
  <head>
	<!-- Alle scripts enz ophalen zodat de pagina een mooie schalende lay out heeft -->
  <title>Ballen trekken ;] </title>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="themes/test.css" />
  <link rel="stylesheet" href="themes/test.min.css" />
  <link rel="stylesheet" href="themes/jquery.mobile.icons.min.css" />
  <link rel="stylesheet" href="themes/jquery.mobile.structure-1.4.5.min.css" />
  <script src="themes/jquery-1.11.1.min.js"></script>
  <script src="themes/jquery.mobile-1.4.5.min.js"></script>
  <style> img {max-width:95%;} </style>
</head>
  <body>
  	<!-- Hier wordt een formpje aangemaakt met daarin een button zodat er naar het volgende plaatje kan worden geklikt: -->
		<div data-role="page">
			<div data-role="header">
				<h1>VINGERS</h1>
			</div>
			<div role="main" class="ui-content">
				<div class="ui-body ui-body-b ui-corner-all">
				<form action="Vingers.php" method="post">
					<label class="ui-hidden-accessible" for="volgende">Volgende:</label>
					<button class="ui-shadow ui-btn ui-corner-all ui-mini" id="volgende" type="submit" name="volgende">VOLGENDE</button>
				</form>
			
			<?php 
			//Checkt of er op de submit button gedrukt is en verhoogd dan de waarde van de session:
			if(isset($_POST["volgende"])){
				$_SESSION["afb"] = $_SESSION["afb"] + 1;
			};
			//Hier wordt op basis van de sessions waarde een afbeelding geprint:
				if($_SESSION["afb"] == 1){
					print "<img src = 'hand1.jpg'>";
				}
				elseif($_SESSION["afb"] == 2){
					print "<img src = 'hand2.jpg'>";
				}
				elseif($_SESSION["afb"] == 3){
					print "<img src = 'hand3.jpg'>";
				}
				elseif($_SESSION["afb"] == 4){
					print "<img src = 'hand4.jpg'>";
				}
				elseif($_SESSION["afb"] == 5){
					print "<img src = 'hand5.jpg'>";
					//hier wordt de session vernietigd dus weer op 0 gezet zodat we weer van voren af aan kunnen beginnen. Joepie!
					session_destroy();
				};
			?>
		
			<div data-role="footer" data-position="fixed">
				<h3>&copy; Vincent & CO </h3>
			</div>
		</div>
  </body>
</html>