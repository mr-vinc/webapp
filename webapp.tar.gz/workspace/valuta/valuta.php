<!DOCTYPE html>
<html>
<head>
 <title>jQuery Mobile page</title>
 <meta charset="utf-8" />
 <!-- Hier staan alle css en style achtige js bestanden-->
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="themes/test.css" />
 <link rel="stylesheet" href="themes/test.min.css" />
 <link rel="stylesheet" href="themes/jquery.mobile.icons.min.css" />
 <link rel="stylesheet" href="themes/jquery.mobile.structure-1.4.5.min.css" />
 <script src="themes/jquery-1.11.1.min.js"></script>
 <script src="themes/jquery.mobile-1.4.5.min.js">
 </script>
</head>

  <body>
		<div data-role="page">
			<div data-role="header">
				<h1>VALUTA</h1>
			</div>
			<div role="main" class="ui-content">
				<p>Met deze WebApp kun je valuta omrekenen naar euro's.</p>
				<!-- Hier maken we een form met darin radiobuttons en een slider. Met de slider kan de hoeveelheid om te rekenen geld gekozen worden en met de radiobuttons kan gekozen vanuit welke munteenheid moet worden gerekend naar euro-->
				<form action="valuta.php" method="post">
					<label for="bedrag">Bedrag:</label>
					<input name="bedrag" id="bedrag" type="range" min="1" max="1000" step="1" value="500" data-highlight="true">	
					<fieldset data-role="controlgroup" data-type="horizontal" data-mini="true">
						<legend>Welke valuta lever je in:</legend>
						<input name="valuta_in" id="in_dollar" type="radio" checked="checked" value="dollar">
						<label for="in_dollar">Am.Dollar</label>
						<input name="valuta_in" id="in_pond" type="radio" value="pond">
						<label for="in_pond">Eng.Pond</label>
						<input name="valuta_in" id="in_yen" type="radio" value="yen">
						<label for="in_yen">Jap.Yen</label>
					</fieldset>
					<label class="ui-hidden-accessible" for="bereken">Bereken:</label>
					<button class="ui-shadow ui-btn ui-corner-all ui-mini" id="bereken" type="submit" name="bereken">BEREKEN</button>
				</form>
<?php
//Hier worden de gegevens uit het form opgehaald en wordt gechekt welke radiobutton aangeklikt is en de waarde van de slider wordt ook opgehaald. Op basis van de muntsoort wordt vervolgens het aantal euro's berekent en geechoeed.
$bedrag = $_POST["bedrag"];
$radioVal = $_POST["valuta_in"];

if($radioVal == "dollar")
{
	  $AE = $bedrag * 0.843383655;
   	echo "De door u gekozen munt en de hoeveelheid daarvan zijn omgerekend in euro's: " . $AE . " Euro";
}
else if ($radioVal == "pond")
{
	  $PE = $bedrag * 1.1259;
    echo "De door u gekozen munt en de hoeveelheid daarvan zijn omgerekend in euro's: " . $PE . " Euro";
}
else if ($radioVal == "yen")
{
	  $YE = $bedrag * 0.00744544504;
   	echo "De door u gekozen munt en de hoeveelheid daarvan zijn omgerekend in euro's: " . $YE . " Euro";
}
?>
			</div>
		</div>
  </body>
</html>